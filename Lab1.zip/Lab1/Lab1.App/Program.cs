﻿using System;

class Student
{
    // Properties
    public string Name { get; set; }
    public int Age { get; set; }
    public double Grade { get; set; }

    // Constructor
    public Student(string name, int age, double grade)
    {
        Name = name;
        Age = age;
        Grade = grade;
    }

    public void Display()
    {
        Console.WriteLine("Name: " + Name + ", Age: " + Age + ", Grade: " + Grade);
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Create 3 objects
        Student s1 = new Student("Ali", 20, 15.5);
        Student s2 = new Student("Sara", 21, 17);
        Student s3 = new Student("Omar", 19, 13);

        // Display students
        s1.Display();
        s2.Display();
        s3.Display();
    }
}
